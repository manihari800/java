package corejava;

class Encapsulation{
    private int ssn;
    private String StudentName;
    private int Stu_Age;

    
    public int getEmpSSN(){
        return ssn;
    }

    public String getEmpName(){
        return StudentName;
    }

    public int getEmpAge(){
        return Stu_Age;
    }

    public void setEmpAge(int newValue){
        Stu_Age = newValue;
    }

    public void setEmpName(String newValue){
        StudentName = newValue;
    }

    public void setEmpSSN(int newValue){
        ssn = newValue;
    }
}
public class question2{
    public static void main(String args[]){
         Encapsulation obj = new Encapsulation();
         obj.setEmpName("monkey D luffy");
         obj.setEmpAge(21);
         obj.setEmpSSN(23345);
         System.out.println("Employee Student_Name: " + obj.getEmpName());
         System.out.println("Employee SSN: " + obj.getEmpSSN());
         System.out.println("Employee Student_Age: " + obj.getEmpAge());
    } 
}